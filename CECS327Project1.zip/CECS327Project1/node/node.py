import socket
import time
# Starts the nodes that communicate with master
def start_node(master_host, master_port):
    print(f"Trying to connect to master at {master_host}:{master_port}")

    #Loop which continuously tries to communicate with master
    while True:
        try:
            # Creates a socket using TCP
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                # Connects to master server using given host and port
                s.connect((master_host, master_port))
                # Sends intial message to let master know it exists and is connected
                message = 'Hello, master'
                s.sendall(message.encode())
                # Then it waits to recieve a message or some response from master
                data = s.recv(1024)
                # Decodes and prints message from master
                print(f"Received: {data.decode()}")
                # Sleeps for 10 seconds to not communicate too fast to master
                time.sleep(10)
                # Sending a trigger message to master which will trigger the broadcast function in master.py
                message = 'broadcast'
                s.sendall(message.encode())
                # Then receives the broadcast from master
                data = s.recv(1024)
                print(f"Received: {data.decode()}")
                # Sleep again to slow down scripts to manageable amount of communcation
                time.sleep(10)
        # For handling connection errors with master
        except ConnectionRefusedError:
            print("Connection refused, retying in 10 seconds")
            time.sleep(10)
        # For handling socket errors that sometimes occured
        except socket.error as e:
            print(f"Socket error: {e}, retrying in 10 seconds")
            time.sleep(10)
# Starting point of script
if __name__ == "__main__":
    # Calls start_node with arguments that match the host and port of master
    start_node('master', 12345)
