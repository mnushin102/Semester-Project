import socket
import threading
import time
import csv
import os

# Lock manages clients from using multiple threads for node connection
clients_lock = threading.Lock()

def start_master():
    # Server listens on all network interfaces
    SERVER = '0.0.0.0'
    # Just picked a port high enough to make sure its not being used
    PORT = 12345
    # List to keep track of node connections
    clients = []

    # Creating socket using TCP
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        # Binding the sevrer to server and port address
        s.bind((SERVER, PORT))
        # Listens to incoming messages
        s.listen()
        print(f"Master listening on {PORT}")
        # Test broadcasting with incorrect message
        print("One time testing incorrect broadcast\n")
        iMessage = 9
        print("Done testing\n")
        broadcast(clients, iMessage)
        # Main communication loop
        while True:
            # Accepting new connections
            conn = s.accept()
            addr = s.accept()
            # cMessage is for Connection message 
            cMessage = f"A new node at {addr} has connected\n"
            broadcast(clients, cMessage)
            # Adding new connections to the list
            with clients_lock:
                clients.append(conn)
            # Using threads to have all nodes be able to run concurrently
            client_thread = threading.Thread(target=client, args=(conn,addr,clients))
            client_thread.start()
# Function to handle communication with nodes
def client(conn,addr, clients):
    # Get ip and port address for logs
    dest_ip = addr
    dest_port = addr
    print(f"Connected by {addr}")
    try:
        with conn:
            while True:
                # Receive data from nodes no more than 1024 bytes
                data = conn.recv(1024)
                # If no data then exit loop
                if not data:
                    break
                # Measure time it takes to receive message
                start = time.time()
                received_message = data.decode()
                print(f"Received: {received_message}")
                end = time.time()
                duration = end - start
                length = len(received_message.encode())
                # Logging the communication
                logs("Unicast", str(dest_ip), "0.0.0.0", dest_port, 12345, "TCP", length, "0x011", duration, "network_activity.csv" )
                # Timing how long it takes to send a message
                start2 = time.time()
                if received_message == "broadcast":
                    # If a node sends this message to master then master will broadcast a message
                    broadcast_message = "This is a broadcast message from master."
                    broadcast(clients, broadcast_message)
                else:
                    # If a node sends any other message then it sends a unicast response to the node
                    response = "Hello from Master"
                    conn.sendall(response.encode())
                    length = len(response.encode())
                    end2 = time.time()
                    duration2 = end2 - start2
                    # Logging the communication
                    logs("Unicast", "0.0.0.0", str(dest_ip), 12345, dest_port, "TCP", length, "0x011", duration2, "network_activity.csv" )
    # Handling for connection errors
    except(ConnectionResetError, BrokenPipeError) as e:
        print("Connection Closed")
    finally:
        # Remove client from the list when done communicating
        with clients_lock:
            clients.remove(conn)
# Function to broadcast a message to all nodes
def broadcast(clients, message):
    # Testing to make sure to send a string and converts it if not a string
    if not isinstance(message, str):
        print("Broadcast message is not a string. Converting...")
        message = str(message)
    length = len(message.encode())
    print(f"Broadcasting message to {len(clients)} nodes")
    start = time.time()
    removed = []
    # Sends the message to all nodes in the list
    with clients_lock:
        for client in clients[:]:
            try:
                client.sendall(message.encode())
            # If it fails to send a broadcast to a node then put it in the remove list to remove later
            except Exception as e:
                print(f"Error sending broadcast message: {e}")
                removed.append(client)
        # Remove any node that encountered an error
        for clients in removed:
            clients.remove(client)
    end = time.time()
    # Again this is just to calculate how long this process takes for the logs
    duration = end - start
    # Logging the communication
    logs("Broadcast", "0.0.0.0", "172.18.0.3", 12345, 12345, "TCP", length, "0x010", duration, "network_activity.csv")
# Function that logs communication of the master and nodes into a csv called network_activity
def logs(type, src_ip, dest_ip, src_port, dest_port, protocol, length, flags, duration, file = "network_activity.csv"):
    # This designs the header with the collumns used in the Project1 example
    header = ["Type", "Time(s)", "Source IP", "Destination IP", "Source Port", "Destination Port", "Protocol", "Length (bytes)", "Flags (hex)"]
    # Checks if file already exists and doesn't need to start over
    file_exists = os.path.isfile(file) and os.path.getsize(file) > 0
    # Format the duration it takes because was getting extremely tiny numbers far below 0 like 4.53E-06 so instead its just 0 if below 0
    formatted_duration = "{:.1f}".format(duration)
    # Open the log file to write into
    with open(file, "a", newline = '') as log:
        csv_writer = csv.writer(log)
        # If the file did not already exist then it write the header, or doesn't write the header if did already exist
        if not file_exists:
            csv_writer.writerow(header)
        # This list forms a row in the csv
        entry = [type, formatted_duration, src_ip, dest_ip, src_port, dest_port, protocol, str(length), flags]
        # Writing entry into csv file
        csv_writer.writerow(entry)
# Starting point of script
if __name__ == "__main__":
    # Calls basically what is the main function to start
    start_master()
