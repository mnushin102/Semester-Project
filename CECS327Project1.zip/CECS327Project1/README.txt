### This folder contains files to run this distributed network and have communication over that network. ###


To run the scripts open the shell and change directory into the correct folder.

For whatever directory you choose, run this command first to create a network:

sudo docker network create proj1-distributed-network

Then run this command in the master directory to build an image of the master script in docker(The period is important to find the correct path to the file which is master.py and Dockerfile in master directory):

sudo docker build -t master-image .

Then in the master directory to run the image and get the master container running use the command:

sudo docker run --name master --network proj1-distributed-network -d master-image

change the directory to node and build the node image in the node directory with:

sudo docker build -t node-image .

Then to run a node use:

sudo docker run --name node1 --network proj1-distributed-network -d node-image

Can run it multiple times just change the name slightly like:

sudo docker run --name node2 --network proj1-distributed-network -d node-image

To stop any of the containers from running you can use the linux command and replace the name with the containers created:

sudo docker stop master 

or to stop all at once:

sudo docker stop master node1 node2 node3 node4

To remove the containers use:

sudo docker rm master node1 node2 node3 node4

To remove the images:

sudo docker rmi master-image node-image

To remove a newtork:

sudo docker network rm proj1-distributed-network